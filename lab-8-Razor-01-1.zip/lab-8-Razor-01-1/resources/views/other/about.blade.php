@extends('layouts.master')

@section('content')
    <p class="quote">
        About me
    </p>

    <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin consequat augue quis turpis rutrum, ac rutrum nisl malesuada.
        Sed sit amet nibh sit amet urna scelerisque eleifend. Nullam lacus diam, viverra eu purus at, eleifend commodo orci.
        Praesent pretium turpis arcu, ut cursus diam elementum sed. Nullam cursus diam semper mi rhoncus eleifend.
        Proin placerat nunc sit amet mauris ullamcorper, vehicula pretium augue pellentesque. Donec imperdiet vehicula augue quis fringilla.
        Curabitur consequat et lorem at cursus. Fusce elit ligula, rutrum ac ultricies sed, condimentum a velit. Praesent porta laoreet nisl at tempus.
        In scelerisque tellus sit amet neque ullamcorper aliquam. Phasellus quis faucibus felis.
        Cras porttitor metus a eleifend congue. Vivamus feugiat nulla in est sodales vulputate.
        Vivamus eget ultricies eros. Quisque ut nisl tristique, venenatis lacus nec, efficitur mi.
    </p>
@endsection
